// Adds a new "Laser" Weapon Property and Physical Property for resistance bypass
Hooks.once("init", () => {
  CONFIG.DND5E.itemProperties.blare = {
    label: "Шум",
	isPhysical: "true"
  };
  CONFIG.DND5E.itemProperties.wreck = {
    label: "Осадный",
	isPhysical: "true"
  };
  CONFIG.DND5E.itemProperties.rend = {
    label: "Охотничий",
	isPhysical: "true"
  };
  CONFIG.DND5E.itemProperties.dwindle = {
    label: "Угасание",
	isPhysical: "true"
  };
  CONFIG.DND5E.itemProperties.spread = {
    label: "Осколочный",
	isPhysical: "true"
  };
  CONFIG.DND5E.itemProperties.explosive = {
    label: "Взрывной",
	isPhysical: "true"
  };
  CONFIG.DND5E.itemProperties.burst = {
    label: "Залп"
  };
  CONFIG.DND5E.itemProperties.concealed = {
    label: "Скрытое"
  };
  CONFIG.DND5E.itemProperties.divine = {
    label: "Божественное наставление"
  };
  CONFIG.DND5E.itemProperties.doublebarrel = {
    label: "Двустволка"
  };
  CONFIG.DND5E.itemProperties.precise = {
    label: "Точное"
  };
  CONFIG.DND5E.itemProperties.prepare = {
    label: "Взведение"
  };
  CONFIG.DND5E.itemProperties.sanctified = {
    label: "Святое"
  };
  CONFIG.DND5E.validProperties.weapon.delete("blare");
  CONFIG.DND5E.validProperties.weapon.delete("wreck");
  CONFIG.DND5E.validProperties.weapon.delete("rend");
  CONFIG.DND5E.validProperties.weapon.delete("dwindle");
  CONFIG.DND5E.validProperties.weapon.delete("spread");
  CONFIG.DND5E.validProperties.weapon.delete("explosive");
  CONFIG.DND5E.validProperties.weapon.add("burst");
  CONFIG.DND5E.validProperties.weapon.add("concealed");
  CONFIG.DND5E.validProperties.weapon.add("divine");
  CONFIG.DND5E.validProperties.weapon.add("doublebarrel");
  CONFIG.DND5E.validProperties.weapon.add("precise");
  CONFIG.DND5E.validProperties.weapon.add("prepare");
  CONFIG.DND5E.validProperties.weapon.add("sanctified");
});